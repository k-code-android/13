package com.example.animationdrawable;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    AnimationDrawable batteryAnimation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView batteryImage = (ImageView) findViewById(R.id.imageView);
        batteryImage.setBackgroundResource(R.drawable.animate);
        batteryAnimation = (AnimationDrawable) batteryImage.getBackground();

        batteryImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                batteryAnimation.start();
            }
        });
    }

}

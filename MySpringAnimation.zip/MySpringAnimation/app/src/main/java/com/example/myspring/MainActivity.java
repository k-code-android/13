package com.example.myspring;

import androidx.appcompat.app.AppCompatActivity;
import androidx.dynamicanimation.animation.DynamicAnimation;
import androidx.dynamicanimation.animation.SpringAnimation;
import androidx.dynamicanimation.animation.SpringForce;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final View imgView = findViewById(R.id.imageView);
        final View imgView2 = findViewById(R.id.imageView2);
        final SpringAnimation springAnimation = new SpringAnimation(imgView, SpringAnimation.TRANSLATION_Y);
        final SpringAnimation springAnimate2 = new SpringAnimation(imgView2, DynamicAnimation.TRANSLATION_Y);
        springAnimation.addUpdateListener(new DynamicAnimation.OnAnimationUpdateListener() {

            // Overriding the method to notify view2 about the change in the view1’s property.
            @Override
            public void onAnimationUpdate(DynamicAnimation dynamicAnimation, float value,
                                          float velocity) {
                springAnimate2.animateToFinalPosition(value);
            }
        });

        imgView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                springAnimation.setStartVelocity(5000f);
                SpringForce spForce = new SpringForce();
                spForce.setFinalPosition(-300f);
                spForce.setStiffness(SpringForce.STIFFNESS_LOW);
                spForce.setDampingRatio(SpringForce.DAMPING_RATIO_HIGH_BOUNCY);
                springAnimation.setSpring(spForce);
                //Begin the animation
                springAnimation.start();
            }
        });


    }
}

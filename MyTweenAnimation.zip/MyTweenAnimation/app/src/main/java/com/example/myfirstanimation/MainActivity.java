package com.example.myfirstanimation;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Animation rotate;
    ImageView rotateView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rotateView = findViewById(R.id.imageView);
    }


    public void rotateCW(View v) {
        rotate = AnimationUtils.loadAnimation(this,R.anim.rotate);
        rotateView.startAnimation(rotate);


    }
    public void rotateCCW(View v) {
        rotate = AnimationUtils.loadAnimation(this,R.anim.rotate_ccw);
        rotateView.startAnimation(rotate);

    }

}
